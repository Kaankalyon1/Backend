import math
import random
import os
import sys
import webbrowser as web
import platform
import time

a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

os.name
sys.version

x = dir(platform)

"""print(x)"""

def Topla(self,i,j):
    print("Veri1:" , x*random.random()*(i+j))
    
def Carp(self,i,j):
    print("veri2:" , x*random.random()*(i*j)) 
    
     


"""web.open("https://python-istihza.yazbel.com/moduller.html")"""