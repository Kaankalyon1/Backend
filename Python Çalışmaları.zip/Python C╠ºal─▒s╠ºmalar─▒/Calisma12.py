import math

a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

class Sınıf1:
    def __init__(self,sayi1,sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
    def Topla(self):
        print("Girilen iki sayının toplamı:" , (self.sayi1+self.sayi2))
    def Carp(self):
        print("Girilen iki sayının çarpımları:" , (self.sayi1 * self.sayi2))
    def SinTopla(self):
        print("Girilen iki sayının sinüslerinin toplamı:" , (math.sin(self.sayi1) + math.sin(self.sayi2)))
    

islem1 = Sınıf1(a,b)


for i in range(10):
    islem1.Topla()
    islem1.Carp()
    islem1.SinTopla()



