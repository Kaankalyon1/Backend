import math


class Sınıf:
    a = 5

b = int(input("Bir sayı giriniz:"))

sayi = Sınıf()

print(sayi.a + b)