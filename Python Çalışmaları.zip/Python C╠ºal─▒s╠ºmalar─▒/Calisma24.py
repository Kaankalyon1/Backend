import math
import random
import time
import os
import sys

a = int(input("İlk sayiyi giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))


class Sinif1:
    def __init__(self , sayi1 , sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
    def Topla(self):
        print("ilk aşama ilk veri:" , (self.sayi1)+(self.sayi2)) 
    def SinTopla(self):
        print("ilk aşama ikinci veri:" , math.sin(self.sayi1) + math.sin(self.sayi2))
    def CosTopla(self):
        print("İlk aşama üçüncü veri:" , math.cos(self.sayi1) + math.sin(self.sayi2))
                   
class Sinif2:
    def __init__(self , sayi1 , sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
    def Carp(self):
        print("İkinci aşama ilk veri:" , (self.sayi1)*(self.sayi2))
    def SinCarp(self):
        print("İkinci aşama ikinci veri:" , (math.sin(self.sayi1)*math.sin(self.sayi2))) 
    def CosCarp(self):
        print("İkinci aşama üçüncü veri:" , (math.cos(self.sayi1)*math.cos(self.sayi2)))
                   
class AnaSinif(Sinif1 , Sinif2):
    pass


data = AnaSinif(a,b)

data.Topla()
data.SinTopla()
data.CosTopla()
data.Carp()
data.SinCarp()
data.CosCarp()


