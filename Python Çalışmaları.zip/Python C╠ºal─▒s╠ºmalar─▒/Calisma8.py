import math

a = int(input("İlk sayı giriniz:"))
b = int(input("İkinci sayı giriniz:"))
c = int(input("Üçüncü sayı giriniz:"))

if a < b:
    for i in range(5):
        print("Girilen ilk sayının sinüsü:" , math.sin(a) , "İkinci sayının sinüsü ise:" , math.sin(b) , " dir." , "Sinüslerinin bölümü ise:" , math.sin(a)/math.sin(b) , " dir.")
elif a == b:
    for i in range(5):
        print("Girilen ilk sayının radyanı:" , math.radians(a) , "İkinci sayının radyanı ise:" , math.radians(b), " dir." , "Radyanlarının toplamı ise:" , (math.radians(a)+math.radians(b)) , " dir.")
elif a > b:
    for i in range(5):
        print("girilen ilk sayının derecesi:" , math.degrees(a), "ikinci sayının derecesi ise:" , math.degrees(b) , " dir." , "Derecelerinin toplamı ise:" , (math.degrees(a)+math.degrees(b)) , " dir.")
elif b < c:        
    for i in range(5):
        print("Girilen ikinci sayının sinüsü:" , math.sin(b) , "üçüncü sayının sinüsü ise:" , math.sin(c), " dir." , "Sinüslerinin toplamları ise:" , (math.sin(b)+math.sin(c)) , " dir.")    
elif b == c:        
    for i in range(5):
        print("Girilen ikinci sayının radyanı:" , math.radians(b) , "üçüncü sayının radyanı ise:" , math.radians(c) , "dir." , "Girilen sayıların radyanlarının toplamları ise:" , (math.radians(b)+math.radians(c)) , " dir.")
elif b > c:        
    for i in range(5):
        print("Girilen ikinci sayının derecesi:" , math.degrees(b) , "üçüncü sayının derecesi ise:" , math.degrees(c) , " dir." , "Girilen sayıların derecelerinin toplamı ise:" , (math.degrees(b)+math.degrees(c)) , " dir.")
elif a < c:        
    for i in range(5):
        print("Girilen ilk sayının sinüsü:" , math.sin(a) , "Girilen üçüncü sayının sinüsü ise:" , math.sin(c) , "dir." , "Girilen sayılarınsa sinüslerinin toplamı ise: " , (math.sin(a)+math.sin(c)) , " dir.")    
elif a == c:    
    for i in range(5):
        print("Girilen ilk sayının radyanı:" , math.radians(a) , "Üçüncü sayının radyanı ise:" , math.radians(c) , " dir." , "Girilen sayıların radyanlarının toplamları ise:" , (math.radians(a)+math.radians(c)) , " dir.")  
elif a > c:     
    for i in range(5):
        print("Girilen ilk sayının derecesi:" , math.degrees(a) , "Üçüncü sayının derecesi ise:" , math.degrees(c) , " dir." , "Girilen sayıların dereceleri toplamı ise:" , (math.degrees(a) + math.degrees(c)) , " dir.")   
         
        
        
        