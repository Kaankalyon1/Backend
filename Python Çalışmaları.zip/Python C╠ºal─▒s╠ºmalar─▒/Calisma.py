sayi1 = int(input("İlk sayiyi giriniz:"))
sayi2 = int(input("İkinci sayiyi giriniz:"))

toplam = sayi1 + sayi2

print("Sayiların toplamları:" , toplam)

if toplam > 100:
    print("Sayıların toplamları 100 den küçüktür.")
elif toplam == 100:
    print("Sayıların toplamları 100 e eşittir.")
elif toplam < 100:
    print("Sayıların toplamları 100 den küçüktür")