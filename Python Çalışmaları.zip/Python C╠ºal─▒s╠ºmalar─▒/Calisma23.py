import math
import random
import time
import os
import sys

a = int(input("İlk sayiyi giriniz:"))
b = int(input("İkinci sayiyi giriniz:"))

class Sinif1:
    def SinTopla(self,sayi1,sayi2):
        print("Veri1:" , math.sin(sayi1)+math.sin(sayi2))

class Sinif2:
    def CosTopla(self,sayi1,sayi2):
        print("Veri2:" , math.cos(sayi1)+math.cos(sayi2))

class Sinif3:
    def SinCarp(self,sayi1,sayi2):
        print("Veri3:" , math.sin(sayi1)*math.sin(sayi2))

class Sinif4:
    def CosCarp(self,sayi1,sayi2):
        print("Veri4:" , math.cos(sayi1)*math.cos(sayi2))
        
class AnaIslemKısmı(Sinif1 , Sinif2 , Sinif3 , Sinif4):
    def AnaIslem(self):
        print("Verilerin kalıtımı başarıyla sağlandı") 
        
        
islem = AnaIslemKısmı()

islem.SinTopla(a,b)
islem.CosTopla(a,b)
islem.SinCarp(a,b)
islem.CosCarp(a,b)               