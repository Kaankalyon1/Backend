import math

sayi1 = int(input("İlk sayi:"))
sayi2 = int(input("İkinci sayi:"))

sayilar = [1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10]

print("Sayıların toplamı:" , (sayi1+sayi2))
print("Sayıların farkı:" , (sayi1-sayi2))
print("Sayıların çarpımı:" , (sayi1*sayi2))

print("Sayıların sinüslerinin toplamı:" , (math.sin(sayi1) + math.sin(sayi2)))
print("Sayıların cosinüslerinin toplamı:" ,(math.cos(sayi1) + math.cos(sayi2)))

print("Sayıların sinüslerinin farkı:" , (math.sin(sayi1)-math.sin(sayi2)))
print("Sayıların cosinüslerinin farkı:" , (math.cos(sayi1)-math.cos(sayi2)))

if (math.sin(sayi1)+math.sin(sayi2)) < 0:
    for i in sayilar:
      print("Sayıların sinüslerinin toplamı 0 dan küçüktür.")
elif (math.sin(sayi1)+math.sin(sayi2)) == 0:
    for i in sayilar:
      print("Sayıların sinüslerinin toplamı 0 a eşittir.")    
elif (math.sin(sayi1)+math.sin(sayi2)) > 0:
    for i in sayilar:
        print("Sayıların sinüslerinin toplamı 0 dan büyüktür.")  
        
        
if (math.cos(sayi1)+math.cos(sayi2)) < 0:
    for i in sayilar:
        print("Sayıların cosinüslerinin toplamı 0 dan küçüktür.")        
elif (math.cos(sayi1)+math.cos(sayi2)) == 0:
    for i in sayilar:
        print("Sayıların cosinüslerinin toplamı 0 a eşittir.")            
elif (math.cos(sayi1)+math.cos(sayi2)) > 0:
    for i in sayilar:
        print("Sayıların cosinüslerinin toplamı 0 dan büyüktür.")      
