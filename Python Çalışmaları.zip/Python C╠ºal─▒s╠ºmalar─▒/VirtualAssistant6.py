import speech_recognition as sr
import nltk

from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords