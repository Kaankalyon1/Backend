import math

a = int(input("İlk sayiyi giriniz:"))
b = int(input("İkinci sayiyi giriniz:"))
c = int(input("Üçüncü sayiyi giriniz:"))


def Topla(a , b):
    return a+b

def Cikar(a , b):
    return a-b

def Carp(a,b):
    return a*b

def SinTopla(a,b):
    return math.sin(a)+math.sin(b)

def CosTopla(a,b):
    return math.cos(a)+math.cos(b)

def SinCarp(a,b):
    return math.sin(a)*math.sin(b)

def CosCarp(a,b):
    return math.cos(a)*math.cos(b)


print("İlk veri:" , Topla(a,b))
print("İkinci veri:" , Topla(b,c))
print("Üçüncü veri:", Topla(a,c))
print("Dördüncü veri:" , Cikar(a,b))
print("Beşinci veri:" , Cikar(b,c))
print("Altıncı veri:" , Cikar(a,c))
print("Yedinci veri:" , Carp(a,b))
print("Sekizinci veri:" , Carp(b,c))
print("Dokuzuncu veri:" , Carp(a,c))
print("Onuncu veri:" , SinTopla(a,b))
print("On Birinci veri:", SinTopla(b,c))
print("On ikinci veri:" , SinTopla(a,c))
print("On üçüncü veri:" , CosTopla(a,b))
print("On dördüncü veri:" , CosTopla(b,c))
print("On beşinci veri:" , CosTopla(a,c))
print("On altıncı veri:" , SinCarp(a,b))
print("On yedinci veri:" , SinCarp(b,c))
print("On sekizinci veri:" , SinCarp(a,c))
print("On dokuzuncu veri:" , CosCarp(a,b))     
print("Yirminci veri:" , CosCarp(b,c))    
print("Yirmi birinci veri:" , CosCarp(a,c))    
    
    
    
    
    