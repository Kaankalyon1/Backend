import random
#import tr

#Load the text file
myfile = open("/Users/kaankalyon/Desktop/PROJECT AND REPORT.txt" , encoding="latin-1")
txt = myfile.read()
myfile.close()
print(txt)

text = txt.lower()

#s = "asasasadsa"
#key = random.sample(s , len(s))
#print("key:" , ''.join(key))

