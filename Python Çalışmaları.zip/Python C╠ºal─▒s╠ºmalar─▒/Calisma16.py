import math
import random
import time

a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

class Sınıf:
    def __init__(self,sayi1,sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
    def Method1(self):
        print("Veri1:" , (random.random()*a) + (random.random()*b)) 
        time.sleep(1)
    def Method2(self):
        print("Veri2:" , (random.random()*a) * (random.random()*b))
        time.sleep(1)
    def Method3(self):
        print("Veri3:" , (random.random() + a) + (random.random() + b)) 
        time.sleep(1) 
    def Method4(self):
        print("Veri4:" , (random.random() + a) * (random.random() + b))     
        time.sleep(1)
        
islem = Sınıf(a,b)                

for i in range(100):
    if a < b:
        islem.Method1()
        islem.Method2()
    elif a > b:
        islem.Method3()        
        islem.Method4()

