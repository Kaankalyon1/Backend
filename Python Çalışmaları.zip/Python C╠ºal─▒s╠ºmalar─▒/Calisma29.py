import math
import random
import time
import os
import sys


def say_hello():
    yield "merhaba"
    yield "hello"
    yield "bonjou"
    
    
my_generator = say_hello()


for greeting in my_generator:
    print(greeting)    