import math
import random
import time

a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

class Sınıf:
    def __init__(self, sayi1, sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
        time.sleep(1)
    def Sintopla(self):
        print("Veri1:" , random.random()*(math.sin(a) + math.sin(b)))
        time.sleep(1)
    def Costopla(self):
        print("Veri2:" , random.random()*(math.cos(a) + math.cos(b)))
        time.sleep(1)
    def Sincarp(self):
        print("Veri3:" , random.random()*(math.sin(a) * math.sin(b)))
        time.sleep(1)
    def Coscarp(self):
        print("Veri4:" , random.random()*(math.cos(a) * math.cos(b)))
        time.sleep(1)
        
        
islem = Sınıf(a,b)


for i in range(100):
    if a < b:
       islem.Sintopla()
       islem.Sincarp()
    elif a > b:    
       islem.Costopla()
       islem.Coscarp()




           