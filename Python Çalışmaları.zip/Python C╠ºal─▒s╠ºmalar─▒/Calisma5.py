import math

a = int(input("İlk sayiyi giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

print("Girilen iki sayının toplamı:" , (a+b))
print("Girilen iki sayının farkı:" , (a-b))
print("Girilen iki sayının çarpımı:" , (a*b))
print("Girilen iki sayının bölümü:" , (a/b))


print("Girilen ilk sayının derecesi:" , math.degrees(a))
print("Girilen ikinci sayının derecesi:" , math.degrees(b))

print("Girilen iki sayının toplamlarının derecesi:" , math.degrees(a+b))
print("Girilen iki sayının farklarının derecesi:" , math.degrees(a-b))


print("Girilen ilk sayının radyanı:" , math.radians(a))
print("Girilen ikinci sayının radyanı:" , math.radians(b))

