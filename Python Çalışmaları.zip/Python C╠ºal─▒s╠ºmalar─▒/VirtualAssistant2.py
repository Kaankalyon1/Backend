import speech_recognition as sr
import nltk

from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

kod1 = int(input("Bir aktivasyon  kodu giriniz:"))
kod2 = int(input("Bir aktivasyon kodu daha giriniz:"))



