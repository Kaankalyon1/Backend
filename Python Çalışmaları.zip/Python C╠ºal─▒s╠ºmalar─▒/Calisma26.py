import math
import random
import time
import sys
import os


a = int(input("İlk sayiyi giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

class Sınıf1:
    def SinTopla(self, sayi1 , sayi2):
        print("Veri1:" , math.sin(sayi1) + math.sin(sayi2))

class Sınıf2(Sınıf1):
    def CosTopla(self , sayi1 , sayi2):
        print("Veri2:" , math.cos(sayi1) + math.cos(sayi2))

class Sınıf3(Sınıf2):
    def SinCarp(self , sayi1 , sayi2):
        print("Veri3" , math.sin(sayi1) * math.sin(sayi2))
        
class Sınıf4(Sınıf3):
    def CosCarp(self , sayi1 , sayi2):
        print("Veri4:" , math.cos(sayi1) * math.cos(sayi2))
        
class Sınıf5(Sınıf4):
    def ToplaSin(self , sayi1 , sayi2):
        print("Veri5:" , math.sin(sayi1 + sayi2)) 
        
class Sınıf6(Sınıf5):
    def ToplaCos(self , sayi1 , sayi2):
        print("Veri6:" , math.cos(sayi1 + sayi2)) 
        
class Sınıf7(Sınıf6):
    def CarpSin(self , sayi1 , sayi2):
        print("Veri7:" , math.sin(sayi1 * sayi2))
                
class Sınıf8(Sınıf7):
    def CarpCos(self , sayi1 , sayi2):
        print("Veri8:" , math.cos(sayi1*sayi2))        
        
        
        
deger = Sınıf1()    
deger2 = Sınıf2()
deger3 = Sınıf3()
deger4 = Sınıf4()
deger5 = Sınıf5()
deger6 = Sınıf6()
deger7 = Sınıf7()
deger8 = Sınıf8()

        
deger.SinTopla(a,b) 
time.sleep(1)       
deger2.CosTopla(a,b)
time.sleep(1)     
deger3.SinCarp(a,b)
time.sleep(1)
deger4.CosCarp(a,b)
time.sleep(1)
deger5.ToplaSin(a,b)
time.sleep(1)
deger6.ToplaCos(a,b)
time.sleep(1)   
deger7.CarpSin(a,b)
time.sleep(1)        
deger8.CarpCos(a,b)                              