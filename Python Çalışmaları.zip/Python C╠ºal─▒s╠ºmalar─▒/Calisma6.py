import math

a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

if a < b:
    for i in range(10):
        print("Girilen sayıların toplamlarının radyanları:" , math.radians(a+b))
        print("Girilen sayıların toplamlarınınn dereceleri:", math.degrees(a+b))
elif a == b:
    for i in range(10):
        print("Girilen iki sayının farklarının radyanları:" , math.radians(a-b))        
        print("Girilen sayıların farklarının dereceleri:" , math.degrees(a-b))
elif a > b:
    for i in range(10):
        print("Girilen iki sayının çarpımlarının radyanları:" , math.radians(a*b))
        print("Girilen sayıların çarpımlarının dereceleri:" , math.degrees(a*b))





