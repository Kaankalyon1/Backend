sayi1 = int(input("İlk sayiyi giriniz:"))
sayi2 = int(input("İkinci sayiyi giriniz:"))

toplam = sayi1+sayi2
fark = sayi1-sayi2
carpım = sayi1*sayi2

print("Girilen sayıların toplamı:" , toplam)
print("Girilen sayıların farkı:" , fark)
print("girilen sayıların carpımı:" , carpım)

if toplam > fark:
    print("girilen sayıların toplamları farklarından büyüktür.")
elif toplam > carpım:
    print("Girilen sayıların toplamları carpımlarından büyüktür.") 
elif toplam < fark:
    print("girilen sayıların toplamları farklarından küçüktür.")    
elif toplam < carpım:
    print("Giirlen sayıların toplamları çarpımlarından küçüktür.") 
elif toplam == carpım:
    print("Girilen sayıların toplamları ve carpımları birbirine eşittir")
elif toplam == fark:
    print("Girilen sayıların toplam ve farkları birbirine eşittir.")    
elif fark < carpım:
    print("Girilen sayıların farkları carpımlarından küçüktür.")
elif fark > carpım:
    print("Girilen sayıların farkları carpımlarından büyüktür.")
elif fark == carpım:
    print("Girilen sayıların farkları carpımlarına eşittir.")
else:
    print("Yorum yok")    
                        
         