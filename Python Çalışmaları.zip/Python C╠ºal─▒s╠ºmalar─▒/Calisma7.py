import math

a = int(input("İlk sayi:"))
b = int(input("İkinci sayi:"))

if a < b:
    for i in range(20):
        print("Girilen sayıların sinüslerinin çarpımı:" , (math.sin(a)*math.sin(b)))
elif a == b:
    for i in range(20):
        print("Girilen sayıların cosinüslerinin çarpımı:" , (math.cos(a)*math.cos(b)))
elif a > b:
    for i in range(20):
        print("Girilen sayıların radyanlarının çarpımı:" , (math.radians(a)*math.radians(b)))



