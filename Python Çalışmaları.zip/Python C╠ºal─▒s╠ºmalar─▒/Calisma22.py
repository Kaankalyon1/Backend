import math
import random
import time
import os
import sys


a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

class Sinif1:
    def Topla(self,sayi1,sayi2):
        print("Girilen sayıların toplamı:" , (sayi1+sayi2)) 

class Sinif2:
    def SinTopla(self,sayi1,sayi2):
        print("Girilen sayıların sinüslerinin toplamı:" , math.sin(sayi1)+math.sin(sayi2))

class Sinif3:
    def CosTopla(self,sayi1,sayi2):
        print("Girilen sayıların cosinüslerinin toplamı:" , math.cos(sayi1)+math.cos(sayi2))

class Islemler(Sinif1 , Sinif2 , Sinif3):
    def Carp(self,sayi1, sayi2):
        print("Girilen veriler:" , sayi1*sayi2)
        

data = Islemler()

data.SinTopla(a,b)
data.CosTopla(a,b)
data.Topla(a,b)
data.Carp(a,b)        
