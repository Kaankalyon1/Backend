import math

a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

terim1 = "0 2 3 4 5 6"
terim2 = "1 2 3 4 5 5 6 6 7"

liste1 = terim1.split()
liste2 = terim2.split()

print("İlk veri:" , liste1*a)
print("İkinci veri:" , liste2*b)


