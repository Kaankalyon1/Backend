sayi = int(input("İlk sayıyı giriniz:"))
sayi2 = int(input("İkinci sayıyı giriniz:"))

sayilar = [1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10]

if sayi < sayi2:
    print("İlk sayı ikincisinden küçüktür. Toplamları:" , (sayi+sayi2))
elif sayi == sayi2:
    print("İki sayıda biribirine eşittir. Farkları:" , (sayi-sayi2))
elif sayi > sayi2:
    print("İlk sayı ikincisinden büyüktür. Çarpımları:" , (sayi*sayi2))    

for i in sayilar:
    print(sayi , sayi2)


