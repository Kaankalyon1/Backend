import math
import time

a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

liste1 = [100]
liste2 = [100]

class Sınıf:
    def __init__(self,sayi1,sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
    def SinTopla(self):
        print("Girilen iki sayının sinüslerinin toplamı" , (math.sin(self.sayi1) + math.sin(self.sayi2)))    
        time.sleep(1)
    def CosTopla(self):
        print("Girilen iki sayının cosinüslerinin toplamı:" , (math.cos(self.sayi1) + math.cos(self.sayi2)))
        time.sleep(1)
    def SinCarp(self):
        print("Girilen iki sayının sinüslerinin çarpımı:" , (math.sin(self.sayi1) * math.sin(self.sayi2)))   
        time.sleep(1)
    def CosCarp(self):
        print("Girilen sayıların cosinüslerinin çarpımı:" , (math.cos(self.sayi1) * math.cos(self.sayi2))) 
        time.sleep(1)        

islem = Sınıf(a,b)


for i in liste1:
    for j in liste2:
        if i < j:
           islem.SinTopla()
        elif i == j:
           islem.CosTopla()
        elif i > j:
           islem.SinCarp()     