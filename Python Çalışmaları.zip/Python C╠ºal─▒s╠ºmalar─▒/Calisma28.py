import math
import random
import time
import os
import sys
from collections import Counter
import re

TOP_K = 20
N_GRAM = 3

def ngrams(n , text):
    for i in range(len(text) -n + 1):
        #Ignore n-grams containing white space
        if not re.search(r'\s' , text[i : i+n]):
            yield text[i:i+n]
            
with open("/Users/kaankalyon/Desktop/PROJECT AND REPORT.docx" , encoding="latin-1") as f:
     text = f.read()    
     print(text)        
