import math
import random
import time

a = float(input("İlk sayıyı giriniz:"))
b = float(input("İkinci sayıyı giriniz:"))

class Sınıf:
    def __init__(self,sayi1,sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
    def Method1(self):
        print("veri1:" , random.uniform(a,b) + random.random()) 
        time.sleep(1)
    def Method2(self):
        print("veri2:" , random.uniform(a,b) * random.random())       
        time.sleep(1)

islem = Sınıf(a,b)

for i in range(100):
    if a < b:
      islem.Method1()
    elif a > b:  
      islem.Method2()

"""print(random.uniform(a,b))
print(random.randint(a,b))"""





