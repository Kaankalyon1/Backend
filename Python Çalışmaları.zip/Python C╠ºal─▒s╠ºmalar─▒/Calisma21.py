from collections.abc import Iterable
import math
import random
import time
import os
import sys
from typing import Any

a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

class Sınıf1:
    def __call__(self, *args: Any, **kwds: Any) -> Any:
        pass
    def Topla(self):
        any.x + any.y
    def Carp(self):
        any.x + any.y
    def Cikar(self):
        any.x * any.y
        
        
sayi = Sınıf1() 

sayi.Topla()
sayi.Carp()
sayi.Cikar()
       
        


