import math
import random
import time
import ModuleDosyası

a = int(input("İlk sayiyi giriniz:"))
b = int(input("İkinci sayiyi giriniz:"))

class Sınıf1:
    def __init__(self,a,b):
        self.a = a
        self.b = b
    def Topla(self):    
        print("İlk veri:" , self.a+self.b)
        time.sleep(1)
    def Carp(self):
        print("İkincvi veri:" , self.a*self.b)
        time.sleep(1)
    def SinCarp(self):
        print("Üçüncü veri:" , math.sin(self.a) * math.sin(self.b)) 
        if math.sin(self.a) * math.sin(self.b) <= 0:
            print("Yenilenmiş üçüncü veri:" , ModuleDosyası.MutlakDeger((math.sin(self.a) * math.sin(self.b))))
        time.sleep(1)
    def Coscarp(self):
        print("Dördüncü veri:" , math.cos(self.a) * math.cos(self.b)) 
        if math.cos(self.a)*math.cos(self.b) <= 0:
            print("Yenilenmiş dördüncü veri:") ,  ModuleDosyası.MutlakDeger((math.cos(self.a)*math.cos(self.b)))
        time.sleep(1)
    def SinTopla(self):
        print("Beşinci veri:" , math.sin(self.a) + math.sin(self.b))
        time.sleep(1)
    def CosTopla(self):
        print("Altıncı veri:" , math.cos(self.a) + math.cos(self.b))    
        time.sleep(1)            
        

for i in range(50):
    for j in range(50):
        sayi = Sınıf1(i,j)
        if a < b:
            sayi.Topla()      
            sayi.Carp()
        elif a == b:
            sayi.SinCarp()
            sayi.Coscarp() 
        elif a > b:
            sayi.SinTopla()
            sayi.CosTopla()  
        else:
            print("Geçersiz komut veya ifade")      