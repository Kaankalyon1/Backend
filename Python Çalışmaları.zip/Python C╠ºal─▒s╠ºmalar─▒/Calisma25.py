import math
import random
import time
import sys
import os

a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

class Sınıf1:
    def __init__(self,sayi1,sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
    def Topla(self):
        print("ilk part ilk veri:" , self.sayi1+self.sayi2)
        time.sleep(1)
    def SinTopla(self):
        print("İlk part ikinci veri:" , (math.sin(self.sayi1) + math.sin(self.sayi2)))
        time.sleep(1)
    def CosTopla(self):
        print("İlk part üçüncü veri:" , (math.cos(self.sayi1) + math.cos(self.sayi2)))   
        time.sleep(1)         

class Sınıf2(Sınıf1):
    def __init__(self,sayi1,sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
    def Carp(self):
        print("ikinci part ilk veri:" , self.sayi1*self.sayi2)
        time.sleep(1)
    def SinCarp(self):
        print("ikinci part ikinci veri:" , (math.sin(self.sayi1)*math.sin(self.sayi2)))
        time.sleep(1)
    def CosCarp(self):
        print("ikinci part üçüncü veri" , (math.cos(self.sayi1)*math.cos(self.sayi2))) 
        time.sleep(1)
        
class Sınıf3(Sınıf2):
    def __init__(self,sayi1,sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2 
    def CarpSin(self):
        print("Üçüncü part ilk veri:" , math.sin(self.sayi1 * self.sayi2)) 
        time.sleep(1)            
    def CarpCos(self):
        print("Üçüncü part ikinci veri:" , math.cos(self.sayi1 * self.sayi2))
        time.sleep(1)

class Sınıf4(Sınıf3):
    def __init__(self,sayi1,sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
    def ToplaSin(self):
        print("Dördüncü part ilk veri:" , math.sin(self.sayi1 + self.sayi2))
        time.sleep(1)
    def ToplaCos(self):
        print("Dördüncü part ikinci veri:" , math.cos(self.sayi1 + self.sayi2))  
        time.sleep(1)      

veri = Sınıf1(a,b)
veri2 = Sınıf2(a,b)
veri3 = Sınıf3(a,b)
veri4 = Sınıf4(a,b)


for i in range(50):
    for j in range(50):
        if i < j:
            veri.Topla()
            veri.SinTopla()
            veri.CosTopla()
        elif i == j:
            veri2.Topla()
            veri2.SinTopla()
            veri2.CosTopla()
            veri2.Carp()
            veri2.CosCarp()
            veri2.SinCarp()
        elif i > j:
            veri3.Carp()
            veri3.CarpCos()
            veri3.CarpSin()
            veri3.Topla()
            veri3.SinTopla()
            veri3.SinCarp()
            veri3.CosCarp()
                    


veri.Topla()

veri2.SinTopla()

veri3.CosTopla()

veri4.SinCarp()



