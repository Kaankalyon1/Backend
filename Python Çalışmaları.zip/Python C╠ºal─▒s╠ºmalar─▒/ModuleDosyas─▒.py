def MutlakDeger(sayi):
    if sayi < 0:
      return (-sayi)