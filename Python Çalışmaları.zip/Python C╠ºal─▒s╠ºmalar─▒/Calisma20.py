import math
import random
import os
import sys
import webbrowser as web

a = int(input("İlk sayıyı giriniz:"))
b = int(input("İkinci sayıyı giriniz:"))

class Sınıf:
    def __init__(self,sayi1,sayi2):
        sayi1 = self.sayi1
        sayi2 = self.sayi2
    def SinTopla(self):
        print("veri1:" , (math.sin(self.sayi1) + math.sin(self.sayi2)))    
    def CosTopla(self):
        print("veri2:" , (math.cos(self.sayi1) + math.cos(self.sayi2)))
    def SinCarp(self):
        print("veri3:" , (math.sin(self.sayi1) * math.sin(self.sayi2)))
    def CosCarp(self):
        print("veri4:" , (math.cos(self.sayi1) * math.cos(self.sayi2)))



for i in range(10):
    for j in range(20):
        digit = Sınıf(i,j)
        if a < b:
            digit.SinTopla()
            web.open("")
        elif a == b:
            digit.CosCarp()    
        elif a > b:
            digit.SinCarp()
        else:
            digit.name()    

