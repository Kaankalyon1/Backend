import math

a = int(input("İlk sayıyı giriniz"))
b = int(input("İkinci sayıyı giriniz:"))

class Sınıf1:
    def __init__(self, sayi1, sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2
        
class Sınıf2:
    def __init__(self,sayi1,sayi2):
        self.sayi1 = sayi1
        self.sayi2 = sayi2        
    def Topla(self):
        print("Toplamları:" , (self.sayi1+self.sayi2))
        
            
blok2 = Sınıf2(a,b)  

blok2.Topla()      
        
        
blok1 = Sınıf1(a,b)

print(blok1.sayi1)
print(blok1.sayi2)