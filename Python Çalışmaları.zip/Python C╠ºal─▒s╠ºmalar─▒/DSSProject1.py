import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import dash
from dash import dcc,html
import plotly.express as px


cash_flows = [-10000, 2000, 3000, 4000, 5000]
discount_rate = 0.1

data = pd.read_csv("/Users/kaankalyon/Desktop/Financal_data.csv")

print("Data columns:" , data.columns)
#print(data.columns , "\n")


print("Data rows:" , data.head())
#print(data.head())


data.columns = data.columns.str.strip()

# Verify the required columns are present
#required_columns = ['Current Assets', 'Current Liabilities', 'Net Income', 'Total Equity']
required_columns = ['Financal Datas;']
for column in required_columns:
    if column not in data.columns:
        raise KeyError(f"Column '{column}' not found in the DataFrame")
    
    
    
def calculate_ratios(df):
    #df['Financal Datas;'] = df['Financal Datas;'] / df['Financal Datas;']
    #df['Return on Equity (ROE)'] = df['Net Income'] / df['Total Equity']
    # Add more ratio calculations as needed
    #print("Deneme datası:" , df['Financal Datas;'])
    df['Financal Datas;']
    return df

# Calculate the ratios
data = calculate_ratios(data)

# Display the updated DataFrame
print("DataFrame with calculated ratios:")
print(data.head())    



def analyze_ratios(df):
    analysis_results = []
    for index, column in df.iterrows():
        result = {}
        if column['Financal Datas;'] < " ":
            result['Financal Datas;'] = 'Low liquidity; consider improving short-term assets.'
        else:
            result['Financal Datas;'] = 'Good liquidity.'

        """ if row['Return on Equity (ROE)'] < 0.1:
            result['ROE'] = 'Low return on equity; consider strategies to improve profitability.'
        else:
            result['ROE'] = 'Good return on equity.'"""

        # Add more analysis criteria as needed
        analysis_results.append(result)
    
    return analysis_results

# Perform the analysis
analysis_results = analyze_ratios(data)

# Display the analysis results
for i, analysis in enumerate(analysis_results):
    print(f"Analysis for record {i+1}:")
    for key, value in analysis.items():
        print(f"{key}: {value}")
    print()
    
    
def decision_support(analysis_results):
    recommendations = []
    for analysis in analysis_results:
        recommendation = {}
        if 'Low liquidity' in analysis['Financal Datas;']:
            recommendation['Liquidity'] = 'Consider increasing cash reserves or reducing short-term liabilities.'
        """ if 'Low return on equity' in analysis['ROE']:
            recommendation['Profitability'] = 'Explore cost-cutting measures or revenue enhancement strategies.'"""
        
        # Add more decision support criteria as needed
        recommendations.append(recommendation)
    
    return recommendations

# Generate recommendations
recommendations = decision_support(analysis_results)

# Display the recommendations
for i, recommendation in enumerate(recommendations):
    print(f"Recommendations for record {i+1}:")
    for key, value in recommendation.items():
        print(f"{key}: {value}")
    print()   
    
    
plt.figure(figsize=(30, 10))
plt.hist(data['Financal Datas;'], bins=20, edgecolor='b', alpha=0.8)
plt.title('----Data Analyze Table----')
plt.xlabel('Financal Datas;')
plt.ylabel('Frequency')
plt.grid(True)
plt.show()     



