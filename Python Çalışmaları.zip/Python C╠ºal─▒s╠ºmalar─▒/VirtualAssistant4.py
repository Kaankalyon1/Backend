import speech_recognition as sr
from gtts import gTTS
import os
import time
"""import nltk

from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords"""

#Burada kullanacağımız 2 parametre bulunuyor, Dil ve Text
"""tts = gTTS(text='Merhaba Dünya', lang='tr')
#Burada oluşturduğumuz ses dosyasını konuma merhaba.mp3 diye kaydediyoruz
tts.save("merhaba.mp3")

#şimdi ise bu dosyayı açalım.
os.system("merhaba.mp3")"""


def speak(audioString):
    print(audioString)
    tts = gTTS(text=audioString, lang='tr')
    tts.save("audio.mp3")
    os.system("audio.mp3")
    
r = sr.Recognizer()
    
with sr.Microphone() as source:
       print("Say something!")
       audio = r.listen(source)
 
    # Burada google'ın ses tanıma sistemini kullandık bu sistem internet gerektiriyor.
       data = ""
       try:
        #burda türkçe olmasını istediğimiz için tanıyıcımızın türkçe sesleri tanımasını ayarlıyoruz.
           data = r.recognize_google(audio, language='tr-tr')
        #burada sesinizin tonuna göre büyük küçük harf geldiği için text verisini lower hale getiriyoruz. 
          # data ​= data.lower()
    #Bu ise gereksiz gürültü sesleri geldiğinde döndüreceği komut
       except sr.UnknownValueError:             
           print("Google Speech Recognition could not understand audio")
           print(data)
 
#Burada ise fonksiyona verilen metin içerisinde yakalanan metinler komut mu diye kontrol ediliyor 
def asistan(data):#Eğer yakalanan metin merhaba ise asistan bize Merhaba Emre sesini döndürecek.#Buraya daha fazla şey ekleyebilirsiniz.if "merhaba" in data:
        speak("Merhaba Emre")

#Asistanı Başlatmadan 2 Saniye bekleyip, Text to Speech yaptırıyoruz.
time.sleep(2)
speak("Merhaba Emre, Sana Nasıl Yardımcı Olabilirim?")

#Bu kısımda sürekli dinlemesini sağlamak için sonsuz döngü içerisine sokuyoruz.
"""while 1:
    data = recordAudio()
    asistan(data)
"""