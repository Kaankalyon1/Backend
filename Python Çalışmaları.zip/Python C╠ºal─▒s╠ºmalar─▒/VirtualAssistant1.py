import nltk
"""import pyaudio"""
import datetime
import requests
import pyttsx3
import speech_recognition as sr

from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

nltk.download('punkt')
nltk.download('stopwords')

def recognize_speech_from_mic():
    recognizer = sr.Recognizer()
    microphone = sr.Microphone()

    with microphone as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        transcript = recognizer.recognize_google(audio)
        print(f"You said: {transcript}")
        return transcript
    except sr.RequestError:
        print("API unavailable")
    except sr.UnknownValueError:
        print("Unable to recognize speech")

    return ""


def process_text(text):
    tokens = word_tokenize(text.lower())
    stop_words = set(stopwords.words('english'))
    filtered_tokens = [word for word in tokens if word.isalnum() and word not in stop_words]
    return filtered_tokens


def recognize_pattern(tokens):
    if "weather" in tokens:
        return "get_weather"
    elif "time" in tokens:
        return "get_time"
    else:
        return "unknown_command"
    
    
    
def execute_action(command):
    engine = pyttsx3.init()
    
    if command == "get_weather":
        # Placeholder for actual weather fetching code
        response = "The weather is sunny."
        print(response)
        engine.say(response)
    elif command == "get_time":
        current_time = datetime.datetime.now().strftime("%H:%M")
        response = f"The current time is {current_time}."
        print(response)
        engine.say(response)
    else:
        response = "Sorry, I did not understand the command."
        print(response)
        engine.say(response)
    
    engine.runAndWait()
    
    
    
def main():
    speech_text = recognize_speech_from_mic()
    if speech_text:
        tokens = process_text(speech_text)
        command = recognize_pattern(tokens)
        execute_action(command)

if __name__ == "__main__":
    main()        






"""kod = int(input("Enter your acticvation  code:"))"""

